#include "Product.h"


void Product_basic(int *A, int Am, int An, int *B, int Bn,  int *C) {
  int i, j, k;
  for (i = 0; i < Am; ++i)
    for (j = 0; j < Bn; ++j) {
      *(C + i * Bn + j) = 0;  // set C[0][0] = 0
      for (k = 0; k < An; ++k) 
	// set C[i][j] += A[i][k] * A[k][j]
	*(C + i * Bn + j) += ( *(A + i * An + k) ) * ( *(B + k * Bn + j) );
    }
}

void Product(int *A, int Am, int An, int *B, int Bn,  int *C) {
}
